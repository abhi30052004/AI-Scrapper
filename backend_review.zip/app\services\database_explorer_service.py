import csv
import io
import json
import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from app.services.onboarding import get_database_path

ALLOWED_TABLES = {
    "sites",
    "site_fields",
    "capture_runs",
    "scraper_configs",
    "extraction_runs",
    "products",
    "change_reports",
    "repair_history",
}


def initialize_database_explorer_db() -> int:
    """Initialize the products table if it doesn't exist and backfill from existing extraction runs."""
    db_path = get_database_path()
    with sqlite3.connect(db_path) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                run_id INTEGER NOT NULL,
                config_id INTEGER,
                site_id INTEGER,
                site_name TEXT,
                title TEXT,
                price TEXT,
                rating TEXT,
                availability TEXT,
                product_url TEXT,
                scraped_at TEXT,
                raw_data_json TEXT,
                FOREIGN KEY(run_id) REFERENCES extraction_runs(id) ON DELETE CASCADE
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_products_run_id ON products(run_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_products_site_id ON products(site_id)")

        # Check existing count
        existing_count = conn.execute("SELECT count(*) FROM products").fetchone()[0]

        # Check if there are extraction runs not yet in products
        conn.row_factory = sqlite3.Row
        runs = conn.execute("""
            SELECT r.id, r.config_id, r.start_url, r.created_at, r.records_json, s.id as site_id, s.name as site_name
            FROM extraction_runs r
            LEFT JOIN scraper_configs c ON r.config_id = c.id
            LEFT JOIN sites s ON r.start_url = s.url OR r.start_url = RTRIM(s.url, '/') OR RTRIM(r.start_url, '/') = RTRIM(s.url, '/')
            ORDER BY r.id ASC
        """).fetchall()

        inserted = 0
        for run in runs:
            run_id = run["id"]
            count_for_run = conn.execute("SELECT count(*) FROM products WHERE run_id = ?", (run_id,)).fetchone()[0]
            if count_for_run > 0:
                continue

            try:
                records = json.loads(run["records_json"]) if run["records_json"] else []
            except Exception:
                records = []

            for rec in records:
                title = rec.get("title") or rec.get("name") or rec.get("product_name")
                price = str(rec.get("price")) if rec.get("price") is not None else None
                rating = str(rec.get("rating")) if rec.get("rating") is not None else None
                availability = str(rec.get("availability")) if rec.get("availability") is not None else None
                product_url = rec.get("product_url") or rec.get("url")

                conn.execute("""
                    INSERT INTO products (
                        run_id, config_id, site_id, site_name,
                        title, price, rating, availability,
                        product_url, scraped_at, raw_data_json
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    run_id,
                    run["config_id"],
                    run["site_id"],
                    run["site_name"] or run["start_url"],
                    title,
                    price,
                    rating,
                    availability,
                    product_url,
                    run["created_at"],
                    json.dumps(rec, ensure_ascii=False)
                ))
                inserted += 1

        return existing_count + inserted


def sync_run_products(
    run_id: int,
    config_id: int,
    start_url: str,
    records: list[dict],
    created_at: str,
) -> int:
    """Insert freshly extracted records into the products table."""
    initialize_database_explorer_db()
    db_path = get_database_path()

    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row
        site_row = conn.execute("""
            SELECT id, name FROM sites
            WHERE url = ? OR url = RTRIM(?, '/') OR RTRIM(url, '/') = RTRIM(?, '/')
            LIMIT 1
        """, (start_url, start_url, start_url)).fetchone()

        site_id = site_row["id"] if site_row else None
        site_name = site_row["name"] if site_row else start_url

        inserted = 0
        for rec in records:
            title = rec.get("title") or rec.get("name") or rec.get("product_name")
            price = str(rec.get("price")) if rec.get("price") is not None else None
            rating = str(rec.get("rating")) if rec.get("rating") is not None else None
            availability = str(rec.get("availability")) if rec.get("availability") is not None else None
            product_url = rec.get("product_url") or rec.get("url")

            conn.execute("""
                INSERT INTO products (
                    run_id, config_id, site_id, site_name,
                    title, price, rating, availability,
                    product_url, scraped_at, raw_data_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                run_id,
                config_id,
                site_id,
                site_name,
                title,
                price,
                rating,
                availability,
                product_url,
                created_at,
                json.dumps(rec, ensure_ascii=False)
            ))
            inserted += 1

        return inserted


def get_database_overview() -> dict[str, Any]:
    """Retrieve full database metadata, connection status, table statistics and record counts."""
    initialize_database_explorer_db()
    db_path = get_database_path()

    if not db_path.exists():
        return {
            "connection_status": "disconnected",
            "database_name": db_path.name,
            "database_size_bytes": 0,
            "database_size_formatted": "0 B",
            "total_tables": 0,
            "total_products": 0,
            "total_sites": 0,
            "total_runs": 0,
            "latest_scraping_timestamp": None,
            "tables": [],
        }

    size_bytes = db_path.stat().st_size
    if size_bytes < 1024:
        size_str = f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        size_str = f"{size_bytes / 1024:.1f} KB"
    else:
        size_str = f"{size_bytes / (1024 * 1024):.1f} MB"

    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row
        existing_tables = [
            r[0] for r in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
            ).fetchall()
        ]

        table_details = []
        for t in sorted(existing_tables):
            if t in ALLOWED_TABLES:
                row_count = conn.execute(f'SELECT count(*) FROM "{t}"').fetchone()[0]
                cols = conn.execute(f'PRAGMA table_info("{t}")').fetchall()
                table_details.append({
                    "name": t,
                    "row_count": row_count,
                    "column_count": len(cols),
                })

        # Key stats
        total_products = conn.execute("SELECT count(*) FROM products").fetchone()[0] if "products" in existing_tables else 0
        total_sites = conn.execute("SELECT count(*) FROM sites").fetchone()[0] if "sites" in existing_tables else 0
        total_runs = conn.execute("SELECT count(*) FROM extraction_runs").fetchone()[0] if "extraction_runs" in existing_tables else 0

        latest_run_ts = None
        if "extraction_runs" in existing_tables:
            latest_row = conn.execute("SELECT created_at FROM extraction_runs ORDER BY id DESC LIMIT 1").fetchone()
            if latest_row and latest_row[0]:
                latest_run_ts = latest_row[0]

    return {
        "connection_status": "connected",
        "database_name": db_path.name,
        "database_size_bytes": size_bytes,
        "database_size_formatted": size_str,
        "total_tables": len(table_details),
        "total_products": total_products,
        "total_sites": total_sites,
        "total_runs": total_runs,
        "latest_scraping_timestamp": latest_run_ts,
        "tables": table_details,
    }


def get_database_tables_metadata() -> list[dict[str, Any]]:
    """List all permitted database tables with column names, data types, and row counts."""
    initialize_database_explorer_db()
    db_path = get_database_path()

    results = []
    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row
        existing_tables = [
            r[0] for r in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
            ).fetchall()
        ]

        for t in sorted(existing_tables):
            if t in ALLOWED_TABLES:
                count = conn.execute(f'SELECT count(*) FROM "{t}"').fetchone()[0]
                cols_raw = conn.execute(f'PRAGMA table_info("{t}")').fetchall()
                columns = [
                    {
                        "name": col["name"],
                        "type": col["type"] or "TEXT",
                        "primary_key": bool(col["pk"]),
                        "not_null": bool(col["notnull"]),
                    }
                    for col in cols_raw
                ]
                results.append({
                    "name": t,
                    "row_count": count,
                    "columns": columns,
                })

    return results


def get_table_data(
    table_name: str,
    page: int = 1,
    limit: int = 20,
    sort_by: str | None = None,
    sort_order: str = "desc",
) -> dict[str, Any]:
    """Safely query a permitted SQLite table with pagination and column inspection."""
    if table_name not in ALLOWED_TABLES:
        raise ValueError(f"Access to table '{table_name}' is not permitted.")

    initialize_database_explorer_db()
    db_path = get_database_path()

    page = max(1, page)
    limit = max(1, min(100, limit))
    offset = (page - 1) * limit

    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row

        # Verify table existence in master
        table_exists = conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name = ?",
            (table_name,)
        ).fetchone()
        if not table_exists:
            raise ValueError(f"Table '{table_name}' does not exist.")

        # Inspect columns
        cols_raw = conn.execute(f'PRAGMA table_info("{table_name}")').fetchall()
        columns = [
            {
                "name": col["name"],
                "type": col["type"] or "TEXT",
                "primary_key": bool(col["pk"]),
            }
            for col in cols_raw
        ]
        column_names = {c["name"] for c in columns}

        # Determine primary key or default sort column
        pk_col = next((c["name"] for c in columns if c["primary_key"]), None)
        order_col = sort_by if sort_by in column_names else (pk_col or (columns[0]["name"] if columns else "rowid"))
        order_dir = "ASC" if sort_order.lower() == "asc" else "DESC"

        # Total count
        total_records = conn.execute(f'SELECT count(*) FROM "{table_name}"').fetchone()[0]

        # Fetch page records
        query = f'SELECT * FROM "{table_name}" ORDER BY "{order_col}" {order_dir} LIMIT ? OFFSET ?'
        rows = conn.execute(query, (limit, offset)).fetchall()

        records = [dict(r) for r in rows]
        total_pages = max(1, (total_records + limit - 1) // limit) if total_records > 0 else 1

        return {
            "table_name": table_name,
            "columns": columns,
            "total_records": total_records,
            "page": page,
            "limit": limit,
            "total_pages": total_pages,
            "records": records,
        }


def search_products(
    search: str | None = None,
    site_id: int | None = None,
    run_id: int | None = None,
    page: int = 1,
    limit: int = 20,
    sort_by: str = "id",
    sort_order: str = "desc",
) -> dict[str, Any]:
    """Search and filter the products table with pagination and metadata."""
    initialize_database_explorer_db()
    db_path = get_database_path()

    page = max(1, page)
    limit = max(1, min(100, limit))
    offset = (page - 1) * limit

    allowed_sort_cols = {
        "id", "title", "price", "rating", "availability",
        "product_url", "scraped_at", "run_id", "site_name", "site_id"
    }
    order_col = sort_by if sort_by in allowed_sort_cols else "id"
    order_dir = "ASC" if sort_order.lower() == "asc" else "DESC"

    where_clauses = []
    params: list[Any] = []

    if search and search.strip():
        term = f"%{search.strip()}%"
        where_clauses.append("(title LIKE ? OR product_url LIKE ? OR site_name LIKE ?)")
        params.extend([term, term, term])

    if site_id is not None:
        where_clauses.append("site_id = ?")
        params.append(site_id)

    if run_id is not None:
        where_clauses.append("run_id = ?")
        params.append(run_id)

    where_sql = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ""

    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row

        count_query = f"SELECT count(*) FROM products {where_sql}"
        total = conn.execute(count_query, params).fetchone()[0]

        select_query = f"""
            SELECT * FROM products
            {where_sql}
            ORDER BY "{order_col}" {order_dir}
            LIMIT ? OFFSET ?
        """
        rows = conn.execute(select_query, params + [limit, offset]).fetchall()

        products = []
        for r in rows:
            item = dict(r)
            raw = None
            if item.get("raw_data_json"):
                try:
                    raw = json.loads(item["raw_data_json"])
                except Exception:
                    raw = None
            item["raw_data"] = raw
            products.append(item)

        total_pages = max(1, (total + limit - 1) // limit) if total > 0 else 1

        return {
            "total": total,
            "page": page,
            "limit": limit,
            "total_pages": total_pages,
            "products": products,
        }


def get_recent_products(limit: int = 20) -> list[dict[str, Any]]:
    """Retrieve the latest scraped products."""
    result = search_products(page=1, limit=limit, sort_by="id", sort_order="desc")
    return result["products"]


def clear_table(table_name: str) -> dict:
    """Delete all rows from a single allowed table and reset its auto-increment counter."""
    if table_name not in ALLOWED_TABLES:
        raise ValueError(f"Access to table '{table_name}' is not permitted.")

    db_path = get_database_path()
    with sqlite3.connect(db_path) as conn:
        exists = conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table_name,)
        ).fetchone()
        if not exists:
            raise ValueError(f"Table '{table_name}' does not exist.")

        count_before = conn.execute(f'SELECT count(*) FROM "{table_name}"').fetchone()[0]
        conn.execute(f'DELETE FROM "{table_name}"')
        # Reset auto-increment sequence if present
        try:
            conn.execute("DELETE FROM sqlite_sequence WHERE name=?", (table_name,))
        except Exception:
            pass

    return {
        "table": table_name,
        "rows_deleted": count_before,
        "message": f"Cleared {count_before} row(s) from table '{table_name}'.",
    }


def clear_all_tables() -> dict:
    """Delete all rows from every allowed data table, in FK-safe order."""
    deletion_order = [
        "products",
        "extraction_runs",
        "change_reports",
        "repair_history",
        "scraper_configs",
        "capture_runs",
        "site_fields",
        "sites",
    ]

    db_path = get_database_path()
    results: dict[str, int] = {}
    total_deleted = 0

    with sqlite3.connect(db_path) as conn:
        conn.execute("PRAGMA foreign_keys = OFF")
        try:
            for table_name in deletion_order:
                exists = conn.execute(
                    "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table_name,)
                ).fetchone()
                if not exists:
                    continue
                count = conn.execute(f'SELECT count(*) FROM "{table_name}"').fetchone()[0]
                conn.execute(f'DELETE FROM "{table_name}"')
                try:
                    conn.execute("DELETE FROM sqlite_sequence WHERE name=?", (table_name,))
                except Exception:
                    pass
                results[table_name] = count
                total_deleted += count
        finally:
            conn.execute("PRAGMA foreign_keys = ON")

    return {
        "tables_cleared": results,
        "total_rows_deleted": total_deleted,
        "message": f"Cleared {total_deleted} row(s) across {len(results)} table(s).",
    }


def export_products_csv(
    search: str | None = None,
    site_id: int | None = None,
    run_id: int | None = None,
) -> tuple[str, str]:
    """Export filtered or all stored products as a CSV string with UTF-8 BOM."""
    initialize_database_explorer_db()
    db_path = get_database_path()

    where_clauses = []
    params: list[Any] = []

    if search and search.strip():
        term = f"%{search.strip()}%"
        where_clauses.append("(title LIKE ? OR product_url LIKE ? OR site_name LIKE ?)")
        params.extend([term, term, term])

    if site_id is not None:
        where_clauses.append("site_id = ?")
        params.append(site_id)

    if run_id is not None:
        where_clauses.append("run_id = ?")
        params.append(run_id)

    where_sql = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ""

    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row
        query = f"SELECT * FROM products {where_sql} ORDER BY id ASC LIMIT 10000"
        rows = conn.execute(query, params).fetchall()

    records = []
    all_keys = ["id", "title", "price", "rating", "availability", "product_url", "site_name", "run_id", "scraped_at"]

    for r in rows:
        item = dict(r)
        raw = {}
        if item.get("raw_data_json"):
            try:
                raw = json.loads(item["raw_data_json"])
            except Exception:
                raw = {}

        # Merge standard columns with any extra raw keys
        combined = {
            "id": item.get("id"),
            "title": item.get("title"),
            "price": item.get("price"),
            "rating": item.get("rating"),
            "availability": item.get("availability"),
            "product_url": item.get("product_url"),
            "site_name": item.get("site_name"),
            "run_id": item.get("run_id"),
            "scraped_at": item.get("scraped_at"),
        }
        for k, v in raw.items():
            if k not in combined:
                combined[k] = v
                if k not in all_keys:
                    all_keys.append(k)
        records.append(combined)

    output = io.StringIO()
    # Write UTF-8 BOM for Excel/editor compatibility
    output.write("\ufeff")

    if records:
        writer = csv.DictWriter(output, fieldnames=all_keys, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(records)
    else:
        writer = csv.writer(output)
        writer.writerow(all_keys)

    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    if run_id:
        filename = f"extraction_run_{run_id}.csv"
    elif search or site_id:
        filename = f"products_filtered_{today}.csv"
    else:
        filename = f"products_export_{today}.csv"

    return output.getvalue(), filename
